// ==UserScript==
// @name         Auto Confirm Button Clicker
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Automatically clicks the "Confirm" button inside articles on chatgpt.com when it appears.
// @author       Your Name
// @match        https://*.chatgpt.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Observe the document for changes to find the "Confirm" button inside articles
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.type === 'childList') {
                const confirmButton = Array.from(document.querySelectorAll('article button'))
                    .find(btn => btn.textContent.trim().toLowerCase() === 'confirm');
                if (confirmButton) {
                    confirmButton.click();
                    console.log('Confirm button clicked.');
                    observer.disconnect(); // Stop observing once clicked
                    return; // Exit after handling
                }
            }
        }
    });

    // Start observing the body for changes
    observer.observe(document.body, { childList: true, subtree: true });
})();